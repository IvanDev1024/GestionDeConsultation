package ma.enset.gestiondeconsultation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeConsultationApplicationTests {

    @Test
    void contextLoads() {
    }

}
